// src/components/Admin/CategoryManagement.jsx
import React, { useEffect, useState } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import { useOutletContext } from "react-router-dom";

// Redux Actions
import { adminCategoryStore, fetchAdminCategories } from '../../../redux/actions/adminCategoriesActions';
import AGgridTable from '../../../components/AGgridTable/AGgridTable';
import CreateUpdateModal from '../../../components/CreateUpdateModal/CreateUpdateModal';
import Filter from '../../../components/Filter/Filter';

const CategoryManagement = () => {
    const { userSession } = useOutletContext();
    const dispatch = useDispatch();

    const [showModal, setShowModal] = useState(false);
    const [editingCategory, setEditingCategory] = useState(null);
    const [filterData, setFilterData] = useState({});

    useEffect(() => {
        dispatch(fetchAdminCategories());
    }, [dispatch]);

    const categories = useSelector(state => state.categories.categories) || [];

    // Table Configuration
    const columnDefs = [
        { field: 'icon', headerName: 'Icon', width: 80 },
        { field: 'name', headerName: 'Category Name', flex: 2 },
        { field: 'details', headerName: 'Description', flex: 3 },
        { field: 'slug', headerName: 'Slug', flex: 1 },
        { field: 'propertyCount', headerName: 'Properties', width: 120 },
        { field: 'active_status', headerName: 'Status', width: 120 },
        { field: 'actions', headerName: 'Actions', width: 200 }
    ];

    // Modal Fields Configuration
    // In your CategoryManagement.jsx - make sure configFields is correct:
    const configFields = [
        { name: 'name', label: 'Category Name', ype: 'text', required: true, colSize: 12 },
        { name: 'slug', label: 'Slug', type: 'slug', required: true, colSize: 12, helpText: 'URL-friendly version of the name' },
        { name: 'details', label: 'Description', type: 'textarea', required: true, colSize: 12, rows: 3 },
        { name: 'icon', label: 'Icon', type: 'icon-selector', required: true, colSize: 12, options: ['🏠', '🏢', '🏡', '🏘️', '🏛️', '📐', '🌆', '🏙️', '🏗️', '💎'] },
        {
            name: 'status', label: 'Status', type: 'select', required: true, colSize: 12,
            options: [
                { value: '1', label: 'Active' },
                { value: '0', label: 'Inactive' }
            ]
        }
    ];

    // Filter Fields Configuration
    const filterFields = [
        {
            name: 'status', label: 'Status', type: 'select', colSize: 3,
            options: [
                { value: '1', label: 'Active' },
                { value: '0', label: 'Inactive' }
            ]
        },
        {
            name: 'search', label: 'Search', type: 'text', colSize: 4,
            placeholder: 'Search by name...'
        }
    ];

    const [formData, setFormData] = useState(
        configFields.reduce((acc, field) => {
            acc[field.name] = field.name === 'icon' ? '🏠' :
                field.name === 'status' ? '1' : '';
            return acc;
        }, {})
    );

    const handleShowModal = (category = null) => {
        if (category) {
            setEditingCategory(category);
            setFormData(configFields.reduce((acc, field) => {
                acc[field.name] = category[field.name] ||
                    (field.name === 'status' ? '1' : '');
                return acc;
            }, {}));
        } else {
            setEditingCategory(null);
            setFormData(configFields.reduce((acc, field) => {
                acc[field.name] = field.name === 'icon' ? '🏠' :
                    field.name === 'status' ? '1' : '';
                return acc;
            }, {}));
        }
        setShowModal(true);
    };

    const handleCloseModal = () => {
        setShowModal(false);
        setEditingCategory(null);
    };

    const handleFormChange = (e) => {
        const { name, value } = e.target;

        if (name === 'name') {
            const slug = value.toLowerCase().replace(/[^a-z0-9]+/g, '-');
            setFormData(prev => ({
                ...prev,
                name: value,
                slug: slug
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                [name]: value
            }));
        }
    };

    const handleSubmit = (formData) => {
        dispatch(adminCategoryStore(formData));
        handleCloseModal();
    };

    const handleDelete = (categoryId) => {
        if (window.confirm('Are you sure you want to delete this category?')) {
            // Implement delete functionality
            console.log('Delete category:', categoryId);
        }
    };

    const handleFilterChange = (e) => {
        const { name, value } = e.target;
        setFilterData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleFilterSubmit = (filters) => {
        // Implement filter logic
        console.log('Apply filters:', filters);
    };

    const handleFilterReset = (resetData) => {
        setFilterData(resetData);
        // Reset filtered data
    };

    return (
        <Container fluid className="category-management">
            <Row className="mb-4">
                <Col className="text-right">
                    <Button variant="success" onClick={() => handleShowModal()}>
                        ➕ Add Category
                    </Button>
                </Col>
            </Row>

            {/* Filters */}
            <Row className="mb-3">
                <Col>
                    <Filter
                        filterFields={filterFields}
                        filterData={filterData}
                        onFilterChange={handleFilterChange}
                        onFilterSubmit={handleFilterSubmit}
                        onReset={handleFilterReset}
                    />
                </Col>
            </Row>

            {/* Data Table */}
            <Row>
                <Col>
                    <Card>
                        <Card.Body>
                            <AGgridTable
                                rowData={categories}
                                columnDefs={columnDefs}
                                onEdit={handleShowModal}
                                onDelete={handleDelete}
                                height="600px"
                            />
                        </Card.Body>
                    </Card>
                </Col>
            </Row>

            {/* Create/Update Modal */}
            <CreateUpdateModal
                show={showModal}
                onHide={handleCloseModal}
                title={editingCategory ? 'Edit Category' : 'Add New Category'}
                formData={formData}
                configFields={configFields}
                onSubmit={handleSubmit}
                onFormChange={handleFormChange}
                submitText={editingCategory ? 'Update Category' : 'Add Category'}
            />
        </Container>
    );
};

export default CategoryManagement;